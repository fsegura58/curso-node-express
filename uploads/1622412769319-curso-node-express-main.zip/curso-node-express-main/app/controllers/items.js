exports.getData = (req, res) => {
    res.send({ data: 'Esto viene desde ITEMS' })
}